public class Dugum {
    int index;
    String kelime;
    public Dugum(int index,String kelime)
    {
        this.index=index;
        this.kelime=kelime;
    }
    public Dugum()
    {}
}
